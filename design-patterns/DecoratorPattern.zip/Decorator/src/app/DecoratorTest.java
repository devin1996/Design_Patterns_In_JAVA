/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

import decorator.Espresso;
import decorator.EspressoWithMilk;



/**
 * Here we show the decorator pattern used for changing the class behavior
 * when there are slight variations of the original class design. 
 * @author Dasun
 */
public class DecoratorTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Espresso espresso = new Espresso();
        EspressoWithMilk espressoWithMilk = new EspressoWithMilk(espresso);
        
        String description = espressoWithMilk.getDescription();
        double cost = espressoWithMilk.getCost();
        
        System.out.println(description);
        System.out.println(cost);
    }
    
}
