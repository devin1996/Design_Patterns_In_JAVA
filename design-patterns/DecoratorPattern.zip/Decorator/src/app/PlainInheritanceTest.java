/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app;

import plain.EspressoWithMilk;

/**
 * Here we show how the plain inheritance can be used for solving the 
 * problem of changing the behavior of the classes.
 * @author Dasun
 */
public class PlainInheritanceTest {
      /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        EspressoWithMilk espressoWithMilk = new EspressoWithMilk();
        String description = espressoWithMilk.getDescription();
        double cost = espressoWithMilk.getCost();
        
        System.out.println(description);
        System.out.println(cost);
    }
}
