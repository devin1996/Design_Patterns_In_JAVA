/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package decorator;

import generic.Beverage;

/**
 *
 * @author Dasun
 */
public class EspressoWithMilk extends Beverage{
    
    Beverage beverageDelegate;
    
    public EspressoWithMilk(Beverage beverage){
        beverageDelegate = beverage;
        String oldDescription = "";
        double oldCost = 0;
        if(beverageDelegate!=null){
            oldDescription = beverageDelegate.getDescription();
            oldCost = beverageDelegate.getCost();
        }
        description = "A latte is a coffee drink made with espresso and steamed milk. The term as used in English is a shortened form of the Italian caffè e latte, caffelatte [kaffeˈlatte] or caffellatte [kaffelˈlatte], which means \'milk coffee\'. ";
        description = oldDescription+System.lineSeparator()+description;
        
        cost = oldCost+15;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public double getCost() {
        return cost;
    }
    
}
