/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plain;

import generic.Beverage;

/**
 *
 * @author Dasun
 */
public class EspressoWithMilk extends Beverage{
    
    public EspressoWithMilk(){
        description = "A latte is a coffee drink made with espresso and steamed milk. The term as used in English is a shortened form of the Italian caffè e latte, caffelatte [kaffeˈlatte] or caffellatte [kaffelˈlatte], which means \'milk coffee\'. ";
        cost = 85;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public double getCost() {
        return cost;
    }
    
}
