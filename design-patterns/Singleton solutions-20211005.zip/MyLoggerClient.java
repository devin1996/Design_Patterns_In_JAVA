/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package singleton;

/**
 *
 * @author Dasun
 */
public class MyLoggerClient extends Thread {

    public static void main(String[] args) {
        MyLoggerClient[] clients = new MyLoggerClient[10];
        for (int i = 0; i < 10; i++) {
            clients[i] = new MyLoggerClient();
            clients[i].start();
        }
    }

    public static void sleep(long num) {
        try {
            Thread.sleep(num);
        } catch (Exception ex) {

        }
    }

    @Override
    public void run() {
        MyLoggerThreads instance;
        System.out.println("Thread "+Thread.currentThread().getId()+" requesting the logger ");
        instance = MyLoggerThreads.getInstance();
        instance.doSomething();
        sleep(1000);
    }
}
