/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package singleton;

/**
 *
 * @author Dasun
 */
public class MyLoggerEager {
    
    private MyLoggerEager(){
        //Lets put a log message to see when the initialization happen
        System.out.println("MyLoggerEager");
    }
    
    private static final MyLoggerEager oneInstance = new MyLoggerEager();
    
    public static MyLoggerEager getInstance(){
        return oneInstance;
    }
    
    public static void main(String []args){
        //We do not call the get instance method
        //Still the object is loaded
    }
    
}
