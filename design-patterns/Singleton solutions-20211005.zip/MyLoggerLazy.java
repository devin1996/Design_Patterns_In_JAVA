/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package singleton;


/**
 *
 * @author Dasun
 */
public class MyLoggerLazy {
    
    private MyLoggerLazy(){
        //Lets put a log message to see when the initialization happen
        System.out.println("MyLoggerLazy");
    }
    
    private static MyLoggerLazy oneInstance;
    
    public static MyLoggerLazy getInstance(){
        if(oneInstance!=null){
            return oneInstance;
        }
        
        if(oneInstance==null){
            oneInstance = new MyLoggerLazy();
        }
        
        return oneInstance;
    }
    
    public void doSomething(){
        System.out.println("Do something");
    }
    
    public static void main(String []args){
        MyLoggerLazy instance;
        System.out.println("Before requesting the instance");
        sleep(1000);
        instance = MyLoggerLazy.getInstance();
        sleep(1000);
        instance.doSomething();
    }
    
    static void sleep(long num){
        try {
            //before we call the get instance method
            //Still the object is not created
            Thread.sleep(num);
        } catch (InterruptedException ex) {
            
        }
    }
}
