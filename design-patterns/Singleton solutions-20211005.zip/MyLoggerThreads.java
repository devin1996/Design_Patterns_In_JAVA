/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package singleton;

/**
 *
 * @author Dasun
 */
public class MyLoggerThreads {

    private static int numberOfInstances = 0;

    private static boolean safe = false;

    private MyLoggerThreads() {
        //Lets put a log message to see when the initialization happen
        System.out.println("MyLogger" + (safe ? "" : "Un") + "Safe");
        numberOfInstances++;
        if (numberOfInstances > 1) {
            throw new RuntimeException("numberOfInstances:" + numberOfInstances + " Oh #$%^&! ");
        }
    }

    private volatile static MyLoggerThreads oneInstance;

    public static MyLoggerThreads getInstance() {
        if (oneInstance != null) {
            return oneInstance;
        }
        if (safe) {
            synchronized (MyLoggerThreads.class) {
                if (oneInstance == null) {
                    oneInstance = new MyLoggerThreads();
                }
            }
        } else {
            if (oneInstance == null) {
                oneInstance = new MyLoggerThreads();
            }
        }

        return oneInstance;
    }

    public void doSomething() {
        System.out.println("Do something");
    }

}
